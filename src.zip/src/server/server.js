const app = require('./app').app;
const https = require('https');
const config = process.env.NODE_ENV == 'production' ? require('./config/config_prod.js') : require('./config/config_dev.js');

//Listening
app.listen(3000, '127.0.0.1');
//https.createServer(config.sslOptions, app).listen(config.HTTPSPort);